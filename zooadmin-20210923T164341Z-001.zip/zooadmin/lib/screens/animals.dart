import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:zooadmin/components/update_animal.dart';
import 'package:zooadmin/constants.dart';
import 'package:zooadmin/service/animal_service.dart';

class Animals extends StatefulWidget {
  const Animals({Key? key}) : super(key: key);

  @override
  _AnimalsState createState() => _AnimalsState();
}

class _AnimalsState extends State<Animals> {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
        future: AnimalService().getAllAnimals(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          if (snapshot.hasError) {
            return const Center(
              child: Text("Error getting animals list!"),
            );
          }
          // ignore: prefer_is_empty
          if (snapshot.data?.length == 0) {
            return const Center(
              child: Text("No any animals found"),
            );
          }
          return GridView.builder(
              shrinkWrap: true,
              itemCount: snapshot.data?.length,
              padding: const EdgeInsetsDirectional.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, crossAxisSpacing: 20, mainAxisSpacing: 20),
              itemBuilder: (context, int index) {
                return Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  decoration: BoxDecoration(
                      color: Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(6)),
                  child: Column(
                    children: [
                      Text(
                        snapshot.data![index]["name"],
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.network(
                          "${ZooConstants.baseURL}/${snapshot.data![index]["photoUrl"]}",
                          width: 250,
                          height: 250,
                          fit: BoxFit.fill,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        snapshot.data![index]["description"],
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.justify,
                        style: const TextStyle(
                            fontWeight: FontWeight.w300, fontSize: 12),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: ElevatedButton(
                            style: ButtonStyle(
                                padding: MaterialStateProperty.resolveWith(
                                    (states) => const EdgeInsets.symmetric(
                                        horizontal: 30, vertical: 10)),
                                elevation: MaterialStateProperty.resolveWith(
                                    (states) => 0),
                                backgroundColor: MaterialStateColor.resolveWith(
                                    (states) => Colors.blue)),
                            onPressed: () {
                              updateAnimal(
                                  context,
                                  snapshot.data![index]["_id"],
                                  snapshot.data![index]["name"],
                                  snapshot.data![index]["description"],
                                  snapshot.data![index]["photoUrl"]);
                            },
                            child: const Text("Update Animal Detail",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ))),
                      ),
                    ],
                  ),
                );
              });
        });
  }
}
