import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:zooadmin/screens/dashboard.dart';
import 'package:zooadmin/service/authentication_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController =
      TextEditingController();
  final TextEditingController _passwordController =
      TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SizedBox(
            width: 300,
            child: SingleChildScrollView(
              child: Center(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Image.asset("assets/app-logo.png"),
                    ),
                    const Text(
                      "Zoo Admin",
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 26),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20.0, vertical: 12),
                      child: TextFormField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                            hintText: "Email",
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: const BorderSide(width: 1))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20.0, vertical: 12),
                      child: TextFormField(
                        controller: _passwordController,
                        keyboardType: TextInputType.emailAddress,
                        obscureText: true,
                        decoration: InputDecoration(
                            hintText: "Password",
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: const BorderSide(width: 1))),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: ElevatedButton(
                          style: ButtonStyle(
                              padding: MaterialStateProperty.resolveWith(
                                  (states) => const EdgeInsets.symmetric(
                                      horizontal: 30, vertical: 10)),
                              elevation: MaterialStateProperty.resolveWith(
                                  (states) => 0),
                              backgroundColor: MaterialStateColor.resolveWith(
                                  (states) => Colors.blue)),
                          onPressed: () {
                            AuthenticationService()
                                .loginUser(_emailController.text.trim(),
                                    _passwordController.text.trim())
                                .then((value) {
                              Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Dashboard(
                                            email: value["email"],
                                            name: value["fullName"],
                                          )),
                                  (route) => false);
                            }).catchError((e) {
                              Fluttertoast.showToast(
                                  msg: "Error logging in. Try again!",
                                  backgroundColor: Colors.red,
                                  textColor: Colors.white);
                            });
                          },
                          child: const Text("Login",
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                              ))),
                    ),
                  ],
                ),
              ),
            )),
      ),
    );
  }
}
