import 'package:flutter/material.dart';
import 'package:zooadmin/service/ticket_service.dart';

class OnlineTickets extends StatefulWidget {
  const OnlineTickets({Key? key}) : super(key: key);

  @override
  _OnlineTicketsState createState() => _OnlineTicketsState();
}

class _OnlineTicketsState extends State<OnlineTickets> {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
        future: TicketService().getAllUserTickets(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          if (snapshot.hasError) {
            return const Center(
              child: Text("Error getting tickets"),
            );
          }
          // ignore: prefer_is_empty
          if (snapshot.data?.length == 0) {
            return const Center(
              child: Text("No any tickets found"),
            );
          }
          return GridView.builder(
              shrinkWrap: true,
              itemCount: snapshot.data?.length,
              padding: const EdgeInsetsDirectional.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  childAspectRatio: 2,
                  crossAxisCount: 3,
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 20),
              itemBuilder: (context, int index) {
                return Container(
                  decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(6)),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20.0),
                        child: Column(
                          children: [
                            Text(
                              snapshot.data![index]["fullName"],
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 18),
                            ),
                            const SizedBox(
                              height: 12,
                            ),
                            Text(
                              snapshot.data![index]["email"],
                              style: const TextStyle(
                                  fontWeight: FontWeight.w300, fontSize: 14),
                            ),
                            const SizedBox(
                              height: 12,
                            ),
                            Text(
                              "Total Bought Tickets: ${snapshot.data![index]["myTickets"].length}",
                              style: const TextStyle(
                                  fontWeight: FontWeight.w300, fontSize: 14),
                            ),
                            const SizedBox(
                              height: 12,
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20),
                              child: ElevatedButton(
                                  style: ButtonStyle(
                                      padding:
                                          MaterialStateProperty.resolveWith(
                                              (states) =>
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 30,
                                                      vertical: 10)),
                                      elevation:
                                          MaterialStateProperty.resolveWith(
                                              (states) => 0),
                                      backgroundColor:
                                          MaterialStateColor.resolveWith(
                                              (states) => Colors.blue)),
                                  onPressed: () {
                                    showModalBottomSheet(
                                        context: context,
                                        shape: const RoundedRectangleBorder(
                                            borderRadius: BorderRadius.only(
                                                topLeft: Radius.circular(12),
                                                topRight: Radius.circular(12))),
                                        builder: (context) {
                                          return SingleChildScrollView(
                                            child: ListView.builder(
                                                padding: const EdgeInsets.only(
                                                    top: 20),
                                                physics:
                                                    const NeverScrollableScrollPhysics(),
                                                shrinkWrap: true,
                                                itemCount: snapshot
                                                    .data![index]["myTickets"]
                                                    .length,
                                                itemBuilder:
                                                    (context, int index1) {
                                                  return Card(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            bottom: 10,
                                                            left: 20,
                                                            right: 20),
                                                    child: ListTile(
                                                      title: Text(
                                                          snapshot.data![index]
                                                                  ["myTickets"]
                                                              [index1]["name"]),
                                                      subtitle: Text(snapshot
                                                                          .data![
                                                                      index][
                                                                  "myTickets"]
                                                              [index1]
                                                          ["description"]),
                                                      trailing: Text(
                                                          "Rs. ${snapshot.data![index]["myTickets"][index1]["price"].toString()}"),
                                                    ),
                                                  );
                                                }),
                                          );
                                        });
                                  },
                                  child:
                                      const Text("View Bought Ticket Details",
                                          style: TextStyle(
                                            fontSize: 18,
                                            color: Colors.white,
                                          ))),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              });
        });
  }
}
