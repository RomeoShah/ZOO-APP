import 'package:flutter/material.dart';
import 'package:zooadmin/components/update_ticket.dart';
import 'package:zooadmin/service/ticket_service.dart';

class Tickets extends StatefulWidget {
  const Tickets({Key? key}) : super(key: key);

  @override
  _TicketsState createState() => _TicketsState();
}

class _TicketsState extends State<Tickets> {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<dynamic>>(
        future: TicketService().getAllTickets(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          if (snapshot.hasError) {
            return const Center(
              child: Text("Error getting tickets"),
            );
          }
          // ignore: prefer_is_empty
          if (snapshot.data?.length == 0) {
            return const Center(
              child: Text("No any tickets found"),
            );
          }
          return GridView.builder(
              shrinkWrap: true,
              itemCount: snapshot.data?.length,
              padding: const EdgeInsetsDirectional.all(10),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  childAspectRatio: 2,
                  crossAxisCount: 3,
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 20),
              itemBuilder: (context, int index) {
                return Container(
                  decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(6)),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data![index]["name"],
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 18),
                            ),
                            Text(
                              "Rs. ${snapshot.data![index]["price"].toString()}",
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold, fontSize: 18),
                            )
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20.0),
                          child: Text(
                            snapshot.data![index]["description"],
                            maxLines: 4,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w300),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: ElevatedButton(
                            style: ButtonStyle(
                                padding: MaterialStateProperty.resolveWith(
                                    (states) => const EdgeInsets.symmetric(
                                        horizontal: 30, vertical: 10)),
                                elevation: MaterialStateProperty.resolveWith(
                                    (states) => 0),
                                backgroundColor: MaterialStateColor.resolveWith(
                                    (states) => Colors.blue)),
                            onPressed: () {
                              updateTicket(
                                  context,
                                  snapshot.data![index]["_id"],
                                  snapshot.data![index]["name"],
                                  snapshot.data![index]["price"].toString(),
                                  snapshot.data![index]["description"]);
                            },
                            child: const Text("Update Ticket Detail",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ))),
                      ),
                    ],
                  ),
                );
              });
        });
  }
}
