import 'package:flutter/material.dart';
import 'package:jwt_decode/jwt_decode.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zooadmin/screens/dashboard.dart';
import 'package:zooadmin/screens/login.dart';

class LoaderPage extends StatefulWidget {
  const LoaderPage({Key? key}) : super(key: key);

  @override
  _LoaderPageState createState() => _LoaderPageState();
}

class _LoaderPageState extends State<LoaderPage> {
  @override
  void initState() {
    checkAuthStatus();
    super.initState();
  }

  checkAuthStatus() async {
    final SharedPreferences _sharedPreferences =
        await SharedPreferences.getInstance();
    final String accessToken =
        _sharedPreferences.getString("access_token") ?? "";
    if (accessToken == "") {
      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const LoginScreen()),
          (route) => false);
    } else {
      Map<String, dynamic> payload =
          Jwt.parseJwt(_sharedPreferences.getString("access_token") ?? "");
      if (payload.isEmpty) {
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => const LoginScreen()),
            (route) => false);
        return;
      } else {
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
                builder: (context) => Dashboard(
                      email: payload["email"],
                      name: payload["fullName"],
                    )),
            (route) => false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(backgroundColor: Colors.white);
  }
}
