import 'dart:typed_data';
import 'dart:html' as html;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:zooadmin/components/add_animal.dart';
import 'package:zooadmin/components/add_ticket.dart';
import 'package:zooadmin/screens/animals.dart';
import 'package:zooadmin/screens/tickets.dart';
import 'package:zooadmin/screens/user_tickets.dart';
import 'package:zooadmin/service/animal_service.dart';
import 'package:zooadmin/service/authentication_service.dart';
import 'package:zooadmin/service/ticket_service.dart';

import 'login.dart';

class Dashboard extends StatefulWidget {
  final String name;
  final String email;
  const Dashboard({Key? key, required this.name, required this.email})
      : super(key: key);

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _ticketnameController = TextEditingController();
  final TextEditingController _ticketdescriptionController =
      TextEditingController();
  Uint8List? animalImagePath;
  int _selectedState = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: _selectedState == 0
            ? const Animals()
            : _selectedState == 1
                ? const Tickets()
                : const OnlineTickets(),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                decoration: const BoxDecoration(
                  color: Colors.blue,
                ),
                child: Column(
                  children: [
                    const CircleAvatar(
                        radius: 40,
                        backgroundImage: NetworkImage(
                            "https://image.flaticon.com/icons/png/512/236/236832.png")),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      widget.name,
                      style: const TextStyle(fontSize: 18, color: Colors.white),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(
                      widget.email,
                      style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w300,
                          color: Colors.white),
                    )
                  ],
                ),
              ),
              ListTile(
                title: Text(
                  "Animals Info",
                  style: TextStyle(
                      fontWeight: _selectedState == 0
                          ? FontWeight.bold
                          : FontWeight.normal),
                ),
                onTap: () {
                  if (_selectedState != 0) {
                    setState(() {
                      _selectedState = 0;
                    });
                  }
                  Navigator.pop(context);
                },
              ),
              ListTile(
                title: Text(
                  'Zoo Packages',
                  style: TextStyle(
                      fontWeight: _selectedState == 1
                          ? FontWeight.bold
                          : FontWeight.normal),
                ),
                onTap: () {
                  if (_selectedState != 1) {
                    setState(() {
                      _selectedState = 1;
                    });
                  }
                  Navigator.pop(context);
                },
              ),
              ListTile(
                title: Text(
                  'Online Tickets',
                  style: TextStyle(
                      fontWeight: _selectedState == 2
                          ? FontWeight.bold
                          : FontWeight.normal),
                ),
                onTap: () {
                  if (_selectedState != 2) {
                    setState(() {
                      _selectedState = 2;
                    });
                  }
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ),
        floatingActionButton: _selectedState == 0 || _selectedState == 1
            ? FloatingActionButton(
                onPressed: () {
                  if (_selectedState == 0) {
                    addNewAnimal(context);
                  } else {
                    addNewTicket(context);
                  }
                },
                child: const Icon(
                  Icons.add,
                  color: Colors.white,
                ))
            : Container(),
        appBar: AppBar(
          actions: [
            IconButton(
                onPressed: () {
                  AuthenticationService().logout().then((value) {
                    Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const LoginScreen()),
                        (route) => false);
                  });
                },
                icon: const Icon(Icons.logout_outlined))
          ],
          title: const Text(
            "Zoo Admin",
            style: TextStyle(
              color: Colors.white,
            ),
          ),
        ));
  }
}
