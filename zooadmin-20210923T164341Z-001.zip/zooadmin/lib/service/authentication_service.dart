import 'dart:io';

import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '/constants.dart';

class AuthenticationService {
  final Dio _dio = Dio();
  Future<bool> logout() async {
    try {
      final SharedPreferences _sharedPreferences =
          await SharedPreferences.getInstance();
      await _sharedPreferences.clear();
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<Map<String, dynamic>> loginUser(String email, String password) async {
    try {
      final SharedPreferences _sharedPreferences =
          await SharedPreferences.getInstance();
      final Response response = await _dio.post(
          "${ZooConstants.baseURL}/adminLogin",
          data: {"email": email, "password": password});
      if (response.statusCode == HttpStatus.ok) {
        _sharedPreferences.setString(
            "access_token", response.data["access_token"]);
        return {
          "fullName": response.data["fullName"],
          "email": response.data["email"],
        };
      } else {
        throw Error();
      }
    } catch (e) {
      throw Exception("Error logging in. Try again!");
    }
  }
}
