import 'dart:io';

import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zooadmin/constants.dart';

class TicketService {
  final Dio _dio = Dio();

  Future<List<dynamic>> getAllTickets() async {
    try {
      final Response response = await _dio.get(
        "${ZooConstants.baseURL}/getAllTickets",
      );
      return response.data;
    } catch (e) {
      throw Future.error("Error getting your tickets");
    }
    // getAllUserTickets
  }

  Future<List<dynamic>> getAllUserTickets() async {
    try {
      final SharedPreferences _sharedPreferences =
          await SharedPreferences.getInstance();
      final Response response = await _dio.get(
        "${ZooConstants.baseURL}/getAllUserTickets",
        options: Options(headers: {
          "Authorization":
              "Bearer ${_sharedPreferences.getString("access_token")}"
        }),
      );
      return response.data;
    } catch (e) {
      throw Future.error("Error getting your tickets");
    }
    // getAllUserTickets
  }

  Future<bool> addNewTicket(
      String name, String description, String price) async {
    try {
      final SharedPreferences _sharedPreferences =
          await SharedPreferences.getInstance();
      final Response response = await _dio.post(
          "${ZooConstants.baseURL}/addNewTicket",
          options: Options(headers: {
            "Authorization":
                "Bearer ${_sharedPreferences.getString("access_token")}"
          }),
          data: {
            "name": name,
            "price": int.parse(price),
            "description": description,
          });
      if (response.statusCode == HttpStatus.created) {
        return true;
      } else {
        throw Error();
      }
    } catch (e) {
      throw Exception("Error adding new ticket");
    }
  }

  Future<bool> updateTicket(
      String ticketId, String name, String description, String price) async {
    try {
      final SharedPreferences _sharedPreferences =
          await SharedPreferences.getInstance();
      final Response response = await _dio.post(
          "${ZooConstants.baseURL}/updateTicket",
          options: Options(headers: {
            "Authorization":
                "Bearer ${_sharedPreferences.getString("access_token")}"
          }),
          data: {
            "ticketId": ticketId,
            "name": name,
            "price": int.parse(price),
            "description": description,
          });
      if (response.statusCode == HttpStatus.ok) {
        return true;
      } else {
        throw Error();
      }
    } catch (e) {
      throw Exception("Error adding new ticket");
    }
  }
}
