import 'dart:io';
import 'dart:typed_data';
import 'package:uuid/uuid.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zooadmin/constants.dart';

class AnimalService {
  final Dio _dio = Dio();

  Future<List<dynamic>> getAllAnimals() async {
    try {
      final Response response =
          await _dio.get("${ZooConstants.baseURL}/getAllAnimals");
      if (response.statusCode == HttpStatus.ok) {
        return response.data;
      } else {
        throw Error();
      }
    } catch (e) {
      throw Exception("Error getting animals list");
    }
  }

  Future<Map<String, dynamic>> updateAnimalDetail(
      String animalId, String name, String description) async {
    try {
      final SharedPreferences _sharedPreferences =
          await SharedPreferences.getInstance();
      final Response response = await _dio.post(
          "${ZooConstants.baseURL}/updateAnimal",
          options: Options(headers: {
            "Authorization":
                "Bearer ${_sharedPreferences.getString("access_token")}"
          }),
          data: {
            "animalId": animalId,
            "name": name,
            "description": description,
          });
      return response.data;
    } catch (e) {
      throw Exception("Error getting animals list");
    }
  }

  Future<Map<String, dynamic>> addNewAnimal(
      String name, String description, Uint8List? photoUrl) async {
    try {
      const uuid = Uuid();
      final SharedPreferences _sharedPreferences =
          await SharedPreferences.getInstance();
      FormData _formData = FormData();
      _formData.files.add(MapEntry(
          "image",
          MultipartFile.fromBytes(
            photoUrl?.buffer.asUint8List() ?? [],
            filename: uuid.v4()
          )));

      _formData.fields.addAll([
        MapEntry("name", name),
        MapEntry("description", description),
      ]);

      final Response response = await _dio.post(
          "${ZooConstants.baseURL}/addNewAnimal",
          options: Options(headers: {
            "Authorization":
                "Bearer ${_sharedPreferences.getString("access_token")}"
          }),
          data: _formData);
      if (response.statusCode == HttpStatus.created) {
        return response.data;
      } else {
        throw Error();
      }
    } on DioError catch (e) {
      throw Exception("Error adding new animal");
    }
  }
}
