  
abstract class ZooConstants {
 static String baseURL = "http://192.168.254.8:3000";
}
//flutter build web