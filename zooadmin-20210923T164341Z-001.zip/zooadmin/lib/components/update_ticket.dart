import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:zooadmin/service/ticket_service.dart';
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;

updateTicket(BuildContext context, String ticketId, String name, String price,
    String description) {
  final TextEditingController _nameController =
      TextEditingController(text: name);
  final TextEditingController _descriptionController =
      TextEditingController(text: description);
  final TextEditingController _priceController =
      TextEditingController(text: price);
  return showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(12), topRight: Radius.circular(12))),
      context: context,
      builder: (context) {
        return SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                const SizedBox(height: 20),
                const Text(
                  "Update Ticket Package",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                      hintText: "Ticket Name",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(width: 1))),
                ),
                const SizedBox(
                  height: 10,
                ),
                TextFormField(
                  controller: _priceController,
                  keyboardType: TextInputType.number,
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.digitsOnly
                  ],
                  decoration: InputDecoration(
                      hintText: "Price",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(width: 1))),
                ),
                const SizedBox(
                  height: 10,
                ),
                TextFormField(
                  maxLines: 4,
                  keyboardType: TextInputType.text,
                  controller: _descriptionController,
                  decoration: InputDecoration(
                      hintText: "Description",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(width: 1))),
                ),
                const SizedBox(
                  height: 10,
                ),
                ElevatedButton(
                    style: ButtonStyle(
                        padding: MaterialStateProperty.resolveWith((states) =>
                            const EdgeInsets.symmetric(
                                horizontal: 30, vertical: 10)),
                        elevation:
                            MaterialStateProperty.resolveWith((states) => 0),
                        backgroundColor: MaterialStateColor.resolveWith(
                            (states) => Colors.blue)),
                    onPressed: () {
                      TicketService()
                          .updateTicket(
                              ticketId,
                              _nameController.text.trim(),
                              _descriptionController.text.trim(),
                              _priceController.text.trim())
                          .then((value) {
                        Navigator.pop(context);
                        Fluttertoast.showToast(
                            msg: "Ticket Package updated Succesfully");
                        html.window.location.reload();
                      }).catchError((e) {
                        Fluttertoast.showToast(
                            msg: "Error updating ticket package. Try again!",
                            backgroundColor: Colors.red,
                            textColor: Colors.white);
                      });
                    },
                    child: const Text("Update Ticket Package",
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                        ))),
              ],
            ),
          ),
        );
      });
}
