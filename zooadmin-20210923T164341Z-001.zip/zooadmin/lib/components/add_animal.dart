import 'dart:typed_data';
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:zooadmin/service/animal_service.dart';

addNewAnimal(BuildContext context) {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  Uint8List? animalImagePath;
  return showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(12), topRight: Radius.circular(12))),
      context: context,
      builder: (context) {
        return SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 20),
              const Text(
                "Add New Animal",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12),
                child: TextFormField(
                  controller: _nameController,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                      hintText: "Animal Name",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(width: 1))),
                ),
              ),
              Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20.0, vertical: 12),
                  child: GestureDetector(
                    onTap: () async {
                      FilePickerResult? result =
                          await FilePicker.platform.pickFiles(
                        dialogTitle: "Select Animal Image",
                        type: FileType.custom,
                        allowedExtensions: ['jpg'],
                      );

                      if (result != null) {
                        animalImagePath = result.files.single.bytes;
                      }
                    },
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                        border: Border.all(width: 1, color: Colors.grey),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Center(
                        child: Text(
                          "Select Animal Image",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  )),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12),
                child: TextFormField(
                  controller: _descriptionController,
                  maxLines: 4,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                      hintText: "Description",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(width: 1))),
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: ElevatedButton(
                    style: ButtonStyle(
                        padding: MaterialStateProperty.resolveWith((states) =>
                            const EdgeInsets.symmetric(
                                horizontal: 30, vertical: 10)),
                        elevation:
                            MaterialStateProperty.resolveWith((states) => 0),
                        backgroundColor: MaterialStateColor.resolveWith(
                            (states) => Colors.blue)),
                    onPressed: () {
                      if (animalImagePath == null) {
                        Fluttertoast.showToast(
                            msg: "Please upload animal image");
                        return;
                      }
                      AnimalService()
                          .addNewAnimal(
                              _nameController.text.trim(),
                              _descriptionController.text.trim(),
                              animalImagePath)
                          .then((value) {
                        Navigator.pop(context);
                        Fluttertoast.showToast(
                            msg: "New Animal Detail added Succesfully");
                                                    html.window.location.reload();

                      }).catchError((e) {
                        Fluttertoast.showToast(
                            msg: "Error adding new animal detail",
                            backgroundColor: Colors.red,
                            textColor: Colors.white);
                      });
                    },
                    child: const Text("Add New Animal",
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                        ))),
              ),
            ],
          ),
        );
      });
}
