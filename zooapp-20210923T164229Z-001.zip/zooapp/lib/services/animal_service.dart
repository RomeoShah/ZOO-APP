import 'dart:io';

import 'package:dio/dio.dart';
import 'package:zooapp/constants.dart';

class AnimalService {
  final Dio _dio = Dio();
  Future<List<dynamic>> getAllAnimals() async {
    try {
      final Response response =
          await _dio.get("${ZooConstants.baseURL}/getAllAnimals");
      if (response.statusCode == HttpStatus.ok) {
        return response.data;
      } else {
        throw Error();
      }
    } catch (e) {
      throw Exception("Error getting animals list");
    }
  }
}
