import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:zooapp/constants.dart';

class AuthenticationService {
  final Dio _dio = Dio();
  final FlutterSecureStorage _flutterSecureStorage =
      const FlutterSecureStorage();

  Future<bool> logout() async {
    try {
      await _flutterSecureStorage.deleteAll();
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<Map<String, dynamic>> loginUser(String email, String password) async {
    try {
      final Response response = await _dio.post("${ZooConstants.baseURL}/login",
          data: {"email": email, "password": password});
      if (response.statusCode == HttpStatus.ok) {
        await _flutterSecureStorage.write(
            key: "access_token", value: response.data["access_token"]);
        return {
          "fullName": response.data["fullName"],
          "email": response.data["email"],
        };
      } else {
        throw Error();
      }
    } catch (e) {
      throw Exception("Error logging in. Try again!");
    }
  }

  Future<Map<String, dynamic>> regiterUser(
      String fullName, String email, String password) async {
    try {
      final Response response = await _dio.post(
          "${ZooConstants.baseURL}/userRegistration",
          data: {"email": email, "password": password, "fullName": fullName});
      if (response.statusCode == HttpStatus.created) {
        await _flutterSecureStorage.write(
            key: "access_token", value: response.data["access_token"]);
        return {
          "fullName": response.data["fullName"],
          "email": response.data["email"],
        };
      } else {
        throw Error();
      }
    } catch (e) {
      throw Exception("Error creating user. Try again!");
    }
  }
}
