import 'dart:io';
import 'package:flutter_secure_storage/flutter_secure_storage.dart'
    hide Options;
import 'package:dio/dio.dart';
import 'package:zooapp/constants.dart';

class TicketService {
  final Dio _dio = Dio();
  final FlutterSecureStorage _flutterSecureStorage =
      const FlutterSecureStorage();

  Future<List<dynamic>> getAllMyTickets() async {
    try {
      String accessToken =
          await _flutterSecureStorage.read(key: "access_token") ?? "";
      final Response response = await _dio.get(
        "${ZooConstants.baseURL}/getAllMyTickets",
        options: Options(headers: {"Authorization": "Bearer $accessToken"}),
      );
      return response.data;
    } catch (e) {
      throw Future.error("Error getting your tickets");
    }
  }

  Future<List<dynamic>> getAllTickets() async {
    try {
      final Response response =
          await _dio.get("${ZooConstants.baseURL}/getAllTickets");
      return response.data;
    } catch (e) {
      throw Future.error("Error getting all tickets");
    }
  }

  Future<bool> buyTicket(String ticketId) async {
    try {
      String accessToken =
          await _flutterSecureStorage.read(key: "access_token") ?? "";
      final Response response = await _dio.post(
          "${ZooConstants.baseURL}/buyTicket",
          options: Options(headers: {"Authorization": "Bearer $accessToken"}),
          data: {"ticketId": ticketId});
      if (response.statusCode == HttpStatus.ok) {
        return true;
      } else {
        throw Error();
      }
    } catch (e) {
      throw Future.error("Error getting all tickets");
    }
  }
}
