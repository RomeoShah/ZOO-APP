import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:zooapp/services/ticket_service.dart';

class TicketsList extends StatefulWidget {
  const TicketsList({Key? key}) : super(key: key);

  @override
  _TicketsListState createState() => _TicketsListState();
}

class _TicketsListState extends State<TicketsList> {
  @override
  Widget build(BuildContext context) {
    return Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        child: FutureBuilder<List<dynamic>>(
          future: TicketService().getAllTickets(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            if (snapshot.hasError) {
              return const Center(
                child: Text("Error getting tickets"),
              );
            }
            // ignore: prefer_is_empty
            if (snapshot.data?.length == 0) {
              return const Center(
                child: Text("No any tickets found"),
              );
            }
            return ListView.builder(
                itemCount: snapshot.data?.length,
                shrinkWrap: true,
                itemBuilder: (context, int index) {
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10, top: 6),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.grey.shade100),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 20),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data![index]["name"],
                              style: const TextStyle(
                                  fontWeight: FontWeight.w500, fontSize: 16),
                            ),
                            Text(
                                "Rs. ${snapshot.data![index]["price"].toString()}",
                                style: const TextStyle(
                                    fontWeight: FontWeight.w500, fontSize: 16))
                          ],
                        ),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Text(
                              snapshot.data![index]["description"],
                              textAlign: TextAlign.left,
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w300),
                            ),
                          ),
                        ),
                        ElevatedButton(
                            style: ButtonStyle(
                                padding: MaterialStateProperty.resolveWith(
                                    (states) => const EdgeInsets.symmetric(
                                        horizontal: 30)),
                                elevation: MaterialStateProperty.resolveWith(
                                    (states) => 0),
                                backgroundColor: MaterialStateColor.resolveWith(
                                    (states) => Colors.blue)),
                            onPressed: () async {
                              await TicketService()
                                  .buyTicket(snapshot.data![index]["_id"])
                                  .then((value) {
                                showModalBottomSheet(
                                    shape: const RoundedRectangleBorder(
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(12),
                                            topRight: Radius.circular(12))),
                                    context: context,
                                    builder: (context) {
                                      return Container(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 12),
                                        height: 100,
                                        decoration: const BoxDecoration(),
                                        child: Column(
                                          children: const [
                                            Align(
                                              alignment: Alignment.topCenter,
                                              child: Text(
                                                "Ticket Purchased",
                                                style: TextStyle(
                                                    fontSize: 22,
                                                    color: Colors.black,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                            SizedBox(height: 10),
                                            Align(
                                              alignment: Alignment.topCenter,
                                              child: Text(
                                                "Your ticket have been confirmed",
                                                style: TextStyle(
                                                    fontSize: 16,
                                                    color: Colors.black,
                                                    fontWeight:
                                                        FontWeight.w300),
                                              ),
                                            ),
                                            SizedBox(height: 6),
                                            Align(
                                              alignment: Alignment.topCenter,
                                              child: Text(
                                                "Please Visit Again. Thank you!",
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.black,
                                                    fontWeight:
                                                        FontWeight.w200),
                                              ),
                                            ),
                                          ],
                                        ),
                                      );
                                    });
                              }).catchError((e) {
                                Fluttertoast.showToast(
                                    msg: "Error buying ticket. Try again!",
                                    textColor: Colors.white,
                                    backgroundColor: Colors.red);
                              });
                            },
                            child: const Text("Buy Now",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ))),
                      ],
                    ),
                  );
                });
          },
        ));
  }
}
