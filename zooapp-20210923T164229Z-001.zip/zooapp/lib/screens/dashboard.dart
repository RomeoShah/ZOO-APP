import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:zooapp/screens/all_animals.dart';
import 'package:zooapp/screens/login.dart';
import 'package:zooapp/screens/map.dart';
import 'package:zooapp/screens/my_tickets.dart';
import 'package:zooapp/screens/tickets_list.dart';
import 'package:zooapp/services/authentication_service.dart';

class Dashboard extends StatefulWidget {
  final String name;
  final String email;
  const Dashboard({Key? key, required this.name, required this.email})
      : super(key: key);

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  int _selectedState = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Zoo App"),
          elevation: 0,
          centerTitle: true,
          actions: [
            IconButton(
                onPressed: () {
                  AuthenticationService().logout().then((value) {
                    Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const LoginScreen()),
                        (route) => false);
                  });
                },
                icon: const Icon(Icons.logout_outlined))
          ],
        ),
        body: _selectedState == 0
            ? const TicketsList()
            : _selectedState == 1
                ? const MapPage()
                : _selectedState == 2
                    ? const MyTicketsList()
                    : const Animals(),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                decoration: const BoxDecoration(
                  color: Colors.blue,
                ),
                child: Column(
                  children: [
                    const CircleAvatar(
                        radius: 40,
                        backgroundImage: NetworkImage(
                            "https://image.flaticon.com/icons/png/512/236/236832.png")),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      widget.name,
                      style: const TextStyle(fontSize: 18, color: Colors.white),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(
                      widget.email,
                      style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w300,
                          color: Colors.white),
                    )
                  ],
                ),
              ),
              ListTile(
                title: Text(
                  "View Packages",
                  style: TextStyle(
                      fontWeight: _selectedState == 0
                          ? FontWeight.bold
                          : FontWeight.normal),
                ),
                onTap: () {
                  if (_selectedState != 0) {
                    setState(() {
                      _selectedState = 0;
                    });
                  }
                  Navigator.pop(context);
                },
              ),
              ListTile(
                title: Text(
                  'Map',
                  style: TextStyle(
                      fontWeight: _selectedState == 1
                          ? FontWeight.bold
                          : FontWeight.normal),
                ),
                onTap: () {
                  if (_selectedState != 1) {
                    setState(() {
                      _selectedState = 1;
                    });
                  }
                  Navigator.pop(context);
                },
              ),
              ListTile(
                title: Text(
                  "My Tickets",
                  style: TextStyle(
                      fontWeight: _selectedState == 2
                          ? FontWeight.bold
                          : FontWeight.normal),
                ),
                onTap: () {
                  if (_selectedState != 2) {
                    setState(() {
                      _selectedState = 2;
                    });
                  }
                  Navigator.pop(context);
                },
              ),
              ListTile(
                title: Text(
                  "Animals Info",
                  style: TextStyle(
                      fontWeight: _selectedState == 3
                          ? FontWeight.bold
                          : FontWeight.normal),
                ),
                onTap: () {
                  if (_selectedState != 3) {
                    setState(() {
                      _selectedState = 3;
                    });
                  }
                  Navigator.pop(context);
                },
              ),
              ListTile(
                title: const Text(
                  'Emergency',
                  style: TextStyle(fontWeight: FontWeight.normal),
                ),
                onTap: () async {
                  const url = "tel:9843626120";
                  try {
                    await launch(url);
                    Navigator.pop(context);
                  } catch (e) {
                    throw 'Could not launch $url';
                  }
                },
              ),
            ],
          ),
        ));
  }
}
