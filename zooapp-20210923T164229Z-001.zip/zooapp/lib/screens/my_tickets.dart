import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:zooapp/services/ticket_service.dart';

class MyTicketsList extends StatefulWidget {
  const MyTicketsList({Key? key}) : super(key: key);

  @override
  _MyTicketsListState createState() => _MyTicketsListState();
}

class _MyTicketsListState extends State<MyTicketsList> {
  @override
  Widget build(BuildContext context) {
    return Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        child: FutureBuilder<List<dynamic>>(
          future: TicketService().getAllMyTickets(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            if (snapshot.hasError) {
              return const Center(
                child: Text("Error getting your tickets"),
              );
            }
            // ignore: prefer_is_empty
            if (snapshot.data?.length == 0) {
              return const Center(
                child: Text("No any tickets found"),
              );
            }
            return ListView.builder(
                itemCount: snapshot.data?.length,
                shrinkWrap: true,
                itemBuilder: (context, int index) {
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10, top: 6),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.grey.shade100),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 20),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              snapshot.data![index]["name"],
                              style: const TextStyle(
                                  fontWeight: FontWeight.w500, fontSize: 16),
                            ),
                            Text(
                                "Rs. ${snapshot.data![index]["price"].toString()}",
                                style: const TextStyle(
                                    fontWeight: FontWeight.w500, fontSize: 16))
                          ],
                        ),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Text(
                              snapshot.data![index]["description"],
                              textAlign: TextAlign.left,
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.w300),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                });
          },
        ));
  }
}
