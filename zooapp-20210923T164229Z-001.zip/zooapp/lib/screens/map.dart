import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapPage extends StatefulWidget {
  const MapPage({Key? key}) : super(key: key);

  @override
  _MapPageState createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  final CameraPosition _kGooglePlex = const CameraPosition(
    target: LatLng(27.673379, 85.311014),
    zoom: 17.5,
  );

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      child: GoogleMap(
        myLocationButtonEnabled: true,
        myLocationEnabled: true,
        mapType: MapType.hybrid,
        initialCameraPosition: _kGooglePlex,
        markers: {
          const Marker(
              markerId: MarkerId("elepahant"),
              infoWindow: InfoWindow(title: "Elephant"),
              position: LatLng(27.674226, 85.310496)),
          const Marker(
              markerId: MarkerId("tiger"),
              infoWindow: InfoWindow(title: "Tiger"),
              position: LatLng(27.673113, 85.309947)),
          const Marker(
              markerId: MarkerId("deer"),
              infoWindow: InfoWindow(title: "Deer"),
              position: LatLng(27.672533, 85.310127)),
          const Marker(
              markerId: MarkerId("hippo"),
              infoWindow: InfoWindow(title: "Hippopotamus"),
              position: LatLng(27.672079, 85.311253)),
          const Marker(
              markerId: MarkerId("snake"),
              infoWindow: InfoWindow(title: "Snake"),
              position: LatLng(27.672934, 85.311768)),
        },
      ),
    );
  }
}
