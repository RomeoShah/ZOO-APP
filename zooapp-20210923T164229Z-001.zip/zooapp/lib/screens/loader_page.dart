import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:zooapp/screens/dashboard.dart';
import 'package:zooapp/screens/login.dart';
import 'package:jwt_decode/jwt_decode.dart';

class LoaderPage extends StatefulWidget {
  const LoaderPage({Key? key}) : super(key: key);

  @override
  _LoaderPageState createState() => _LoaderPageState();
}

class _LoaderPageState extends State<LoaderPage> {
  final FlutterSecureStorage _flutterSecureStorage =
      const FlutterSecureStorage();
  @override
  void initState() {
    checkAuthStatus();
    super.initState();
  }

  checkAuthStatus() async {
    String? accessToken = await _flutterSecureStorage.read(key: "access_token");
    if (accessToken == null) {
      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const LoginScreen()),
          (route) => false);
    } else {
      Map<String, dynamic> payload = Jwt.parseJwt(accessToken);
      if (payload.isEmpty) {
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => const LoginScreen()),
            (route) => false);
      } else {
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
                builder: (context) => Dashboard(
                    name: payload["fullName"], email: payload["email"])),
            (route) => false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.white,
    );
  }
}
