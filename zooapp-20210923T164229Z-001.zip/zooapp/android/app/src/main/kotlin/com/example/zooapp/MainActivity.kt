package com.example.zooapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
