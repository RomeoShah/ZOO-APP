const TicketSchema = require("../schemas/ticketSchema");
const UserSchema = require("../schemas/userSchema");

module.exports = {
  getAllTicketsBought: async (req, res) => {
    try {
      const allBoughtTickets = await UserSchema.find(
        {},
        "email fullName myTickets"
      ).populate({
          path: "myTickets",
          model: TicketSchema
      }).exec();
      res.status(200).send(allBoughtTickets);
    } catch (error) {
        console.log(error)
      return res.status(500).send("Error getting user bought tickets list!!");
    }
  },
};
