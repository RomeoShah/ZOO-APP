const { Types } = require("mongoose");
const TicketSchema = require("../schemas/ticketSchema");
const UserSchema = require("../schemas/userSchema");

module.exports = {
  getAllMyTickets: async (req, res) => {
    try {
      const allMyTicketsList = await UserSchema.findOne({
        _id: Types.ObjectId(req.body.id),
      });

      const allMyTicketsDetail = await TicketSchema.find()
        .where("_id")
        .in(allMyTicketsList.myTickets)
        .exec();

      res.status(200).send(allMyTicketsDetail);
    } catch (error) {
      return res.status(500).send("Error getting my tickets list!!");
    }
  },
};
