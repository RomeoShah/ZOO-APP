const TicketSchema = require("../schemas/ticketSchema");

module.exports = {
  getAllTickets: async (req, res) => {
    try {
      const allTicketsList = await TicketSchema.find();

      res.status(200).send(allTicketsList);
    } catch (error) {
      return res.status(500).send("Error getting all tickets list!!");
    }
  },
};
