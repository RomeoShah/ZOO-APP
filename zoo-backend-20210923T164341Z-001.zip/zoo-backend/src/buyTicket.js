const { Types } = require("mongoose");
const UserSchema = require("../schemas/userSchema");

module.exports = {
  buyTicket: async (req, res) => {
    try {
      await UserSchema.findByIdAndUpdate(
        req.body.id,
        {
          $push: {
            myTickets: Types.ObjectId(req.body.ticketId),
          },
        },
        {
          new: true,
        }
      );
      res.status(200).send("New Ticket Bought");
    } catch (error) {
      return res.status(500).send("Error registering new user!!");
    }
  },
};
