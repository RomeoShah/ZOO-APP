const jsonwebtoken = require("jsonwebtoken");

function accessTokenGenerator(fullName, email, id) {
  const access_token = jsonwebtoken.sign(
    {
      fullName: fullName,
      email: email,
      access_id: id,
      token: "access",
    },
    process.env.ACCESS_TOKEN_SECRET_KEY
  );

  return access_token;
}

function accessTokenValidator(authorizationHeader) {
  try {
    var access_token = authorizationHeader.split(" ")[1];
    return jsonwebtoken.verify(
      access_token,
      process.env.ACCESS_TOKEN_SECRET_KEY,
      function (error, e) {
        if (error != null) return null;
        return e.access_id;
      }
    );
  } catch (error) {
    return null;
  }
}

module.exports = { accessTokenGenerator, accessTokenValidator };
