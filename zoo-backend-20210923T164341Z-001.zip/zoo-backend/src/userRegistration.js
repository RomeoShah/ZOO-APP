const UserSchema = require("../schemas/userSchema");
const bcrypt = require("bcryptjs");
const accessTokenGenerator = require("../src/jwtToken");

module.exports = {
  register: async (req, res) => {
    try {
      const user = await UserSchema.findOne({ email: req.body.email }, "email");

      if (user) {
        return res.status(409).send("User Already Exists");
      }

      let register = new UserSchema({
        email: req.body.email,
        fullName: req.body.fullName,
      });

      const salting = await bcrypt.genSalt(8);

      register.password = await bcrypt.hash(req.body.password, salting);

      await register.save();

      res.status(201).send({
        fullName: register.fullName,
        email: register.email,
        access_token: accessTokenGenerator.accessTokenGenerator(
          register.fullName,
          register.email,
          register._id.toString()
        ),
      });
    } catch (error) {
      return res.status(500).send("Error registering new user!!");
    }
  },
};
