const TicketSchema = require("../schemas/ticketSchema");

module.exports = {
  addNewTicket: async (req, res) => {
    try {
      const ticketDetail = new TicketSchema({
        name: req.body.name,
        price: req.body.price,
        description: req.body.description,
      });

      await ticketDetail.save();

      res.status(201).send(ticketDetail);
    } catch (error) {
      return res.status(500).send("Error adding new tickets!!");
    }
  },
};
