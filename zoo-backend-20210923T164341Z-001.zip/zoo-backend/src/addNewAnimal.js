const AnimalSchema = require("../schemas/animalSchema");

module.exports = {
  addNewAnimal: async (req, res) => {
    try {
      const animalDetail = new AnimalSchema({
        name: req.body.name,
        photoUrl: req.file.filename,
        description: req.body.description,
      });

      await animalDetail.save();

      res.status(201).send(animalDetail);
    } catch (error) {
      console.log(error)
      return res.status(500).send("Error adding new animal!!");
    }
  },
};
