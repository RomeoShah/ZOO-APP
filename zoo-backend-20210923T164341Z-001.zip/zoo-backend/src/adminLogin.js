const accessTokenGenerator = require("./jwtToken");
const bcrypt = require("bcryptjs");
const AdminSchema = require("../schemas/adminSchema");

module.exports = {
  adminLogin: async (req, res) => {
    try {
      let user = await AdminSchema.findOne(
        {
          email: req.body.email,
        },
        "password email fullName"
      );

      if (user == null) {
        return res.status(404).send("User Doesnot Exists");
      }

      let passwordComparator = await bcrypt.compare(
        req.body.password,
        user.password
      );

      if (!passwordComparator) {
        return res.status(401).send("Invalid Password");
      }

      res.status(200).send({
        fullName: user.fullName,
        email: user.email,
        access_token: accessTokenGenerator.accessTokenGenerator(
          user.fullName,
          user.email,
          user._id.toString()
        ),
      });
    } catch (error) {
      return res.status(500).send("Internal Server Error");
    }
  },
};
