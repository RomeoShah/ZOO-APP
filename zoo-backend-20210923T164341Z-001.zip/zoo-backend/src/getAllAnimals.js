const AnimalSchema = require("../schemas/animalSchema");

module.exports = {
  getAllAnimals: async (req, res) => {
    try {
      const allAnimalsList = await AnimalSchema.find();

      res.status(200).send(allAnimalsList);
    } catch (error) {
      return res.status(500).send("Error getting all animals list!!");
    }
  },
};
