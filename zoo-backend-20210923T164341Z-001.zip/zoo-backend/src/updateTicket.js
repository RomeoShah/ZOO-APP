const TicketSchema = require("../schemas/ticketSchema");

module.exports = {
  updateTicket: async (req, res) => {
    try {
      const ticketDetail = await TicketSchema.findByIdAndUpdate(
        req.body.ticketId,
        {
          name: req.body.name,
          price: req.body.price,
          description: req.body.description,
        },
        {
          new: true,
        }
      );

      res.status(200).send(ticketDetail);
    } catch (error) {
      return res.status(500).send("Error registering new user!!");
    }
  },
};
