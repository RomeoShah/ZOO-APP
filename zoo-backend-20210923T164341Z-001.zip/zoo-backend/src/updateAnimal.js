const AnimalSchema = require("../schemas/animalSchema");

module.exports = {
  updateAnimal: async (req, res) => {
    try {
      const updatedAnimal = await AnimalSchema.findByIdAndUpdate(
        req.body.animalId,
        {
          name: req.body.name,
          description: req.body.description,
        },
        {
          new: true,
        }
      );

      res.status(200).send(updatedAnimal);
    } catch (error) {
      return res.status(500).send("Error updating animal!!");
    }
  },
};
