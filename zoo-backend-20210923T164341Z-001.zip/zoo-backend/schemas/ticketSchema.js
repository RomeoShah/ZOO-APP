const mongoose = require("mongoose");

const ticketSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
  },
  { collection: "Ticket", timestamps: true }
);

const database = mongoose.connection.useDb("Zoo");

const TicketSchema = database.model("TicketSchema", ticketSchema);

module.exports = TicketSchema;
