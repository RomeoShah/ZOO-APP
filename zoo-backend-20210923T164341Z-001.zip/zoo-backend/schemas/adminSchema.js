const mongoose = require("mongoose");

const adminSchema = new mongoose.Schema(
  {
    email: {
      required: true,
      trim: true,
      type: String,
    },
    password: {
      type: String,
      required: true,
      trim: true,
      minlength: 6,
    },
    fullName: {
      required: true,
      minlength: 3,
      trim: true,
      maxlength: 25,
      type: String,
    },
    acceptTerms: {
      type: Boolean,
      default: true,
    },
    isVerified: {
      type: Boolean,
      default: false,
    },
  },
  { collection: "Admin", timestamps: true }
);

const database = mongoose.connection.useDb("Zoo");

const AdminSchema = database.model("AdminSchema", adminSchema);

module.exports = AdminSchema;
