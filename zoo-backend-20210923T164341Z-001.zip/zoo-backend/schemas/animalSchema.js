const mongoose = require("mongoose");

const animalSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    photoUrl: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
  },
  { collection: "Animal", timestamps: true }
);

const database = mongoose.connection.useDb("Zoo");

const AnimalSchema = database.model("AnimalSchema", animalSchema);

module.exports = AnimalSchema;
