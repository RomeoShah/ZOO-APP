const express = require("express");
const dotenv = require("dotenv").config();
const mongoose = require("mongoose");
const bodyparser = require("body-parser");
const cors = require("cors");
const userRegistration = require("./src/userRegistration");
const { accessTokenValidator } = require("./src/jwtToken");
const login = require("./src/login");
const addNewTicket = require("./src/addNewTicket");
const updateTicket = require("./src/updateTicket");
const getAllTickets = require("./src/getAllTickets");
const addNewAnimal = require("./src/addNewAnimal");
const updateAnimal = require("./src/updateAnimal");
const buyTicket = require("./src/buyTicket");
const getAllMyTickets = require("./src/getAllMyTickets");
const adminLogin = require("./src/adminLogin");
const getAllAnimals = require("./src/getAllAnimals");
const getAllTicketsBought = require("./src/getAllTicketsBought");
const upload = require("./utils/fileUploadConfig");

const app = express();

app.use(cors());

app.use(bodyparser.urlencoded({ extended: false }));

app.use(bodyparser.json());

app.use(express.json());

app.use(express.static('files'));

app.post("/userRegistration", userRegistration.register);

app.post("/login", login.login);

app.post("/adminLogin", adminLogin.adminLogin);

app.get("/getAllTickets", getAllTickets.getAllTickets);

app.get("/getAllAnimals", getAllAnimals.getAllAnimals);

app.use(function (req, res, next) {
  const tokenValidationResponse = accessTokenValidator(
    req.headers.authorization
  );
  if (tokenValidationResponse == null) return res.sendStatus(403);
  req.body.id = tokenValidationResponse;
  next();
});

app.post("/addNewTicket", addNewTicket.addNewTicket);

app.post("/updateTicket", updateTicket.updateTicket);

app.post("/addNewAnimal", upload.single("image") , addNewAnimal.addNewAnimal);

app.post("/updateAnimal", updateAnimal.updateAnimal);

app.post("/buyTicket", buyTicket.buyTicket);

app.get("/getAllUserTickets", getAllTicketsBought.getAllTicketsBought);

app.get("/getAllMyTickets", getAllMyTickets.getAllMyTickets);

app.listen(3000, () => {
  mongoose
    .connect(process.env.MONGO_CREDENTIALS, {
      useUnifiedTopology: true,
    })
    .then(() => {
      console.log("Server is Running");
    })
    .catch((e) => {
      console.log(e)
      process.exit(0);
    });
});
